package com.example.adskiphelper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.SystemClock;
import java.util.Locale;

public class AdSkipAccessibilityService extends AccessibilityService {
    private long lastAction = 0L;

    private static final String[] SAFE = {
        "skip", "пропустить", "пропустить рекламу",
        "close", "закрыть", "закрыть рекламу",
        "dismiss", "continue", "продолжить",
        "×", "✕", "✖"
    };

    private static final String[] NEVER = {
        "скачать", "download", "install", "установить",
        "купить", "buy", "играть", "play", "open", "открыть"
    };

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        if (SystemClock.uptimeMillis() - lastAction < 1200) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            AccessibilityNodeInfo n = find(root);
            if (n != null) {
                AccessibilityNodeInfo target = n.isClickable() ? n : findClickableParent(n);
                if (target != null) {
                    target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    lastAction = SystemClock.uptimeMillis();
                    if (target != n) target.recycle();
                }
                n.recycle();
            }
        } finally {
            root.recycle();
        }
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo node) {
        String text = normalize(node.getText());
        String desc = normalize(node.getContentDescription());

        if (isNever(text) || isNever(desc)) return null;

        if (isSafe(text) || isSafe(desc)) {
            return AccessibilityNodeInfo.obtain(node);
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child == null) continue;
            AccessibilityNodeInfo hit = find(child);
            child.recycle();
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findClickableParent(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p = n.getParent();
        while (p != null) {
            if (p.isClickable()) return p;
            AccessibilityNodeInfo next = p.getParent();
            p.recycle();
            p = next;
        }
        return null;
    }

    private boolean isSafe(String s) {
        if (s.isEmpty()) return false;
        for (String w : SAFE) {
            if (s.equals(w) || s.contains(w)) return true;
        }
        return false;
    }

    private boolean isNever(String s) {
        if (s.isEmpty()) return false;
        for (String w : NEVER) {
            if (s.equals(w) || s.contains(w)) return true;
        }
        return false;
    }

    private String normalize(CharSequence s) {
        return s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
    }

    @Override public void onInterrupt() {}
}
