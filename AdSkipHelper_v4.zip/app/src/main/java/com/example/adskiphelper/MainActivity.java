package com.example.adskiphelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 64, 48, 48);

        TextView title = new TextView(this);
        title.setText("Ad Skip Helper");
        title.setTextSize(28);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nАвтоматически ищет доступные кнопки пропуска/закрытия рекламы.\n\nУмеет нажимать и значки ✕ / ▶| в углу рекламы (если рядом есть метка «Реклама»). Не нажимает «Скачать», «Забрать бонус», баннеры и ссылки.\n\nВключи сервис в Настройки → Специальные возможности.");
        info.setTextSize(16);
        box.addView(info);

        Button settings = new Button(this);
        settings.setText("Открыть специальные возможности");
        settings.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(settings);

        setContentView(box);
    }
}
